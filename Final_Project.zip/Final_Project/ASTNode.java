public abstract class ASTNode {
    public abstract String generateLLVM(IRBuilder builder);
}
